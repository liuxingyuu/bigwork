from flask import Flask, jsonify
from flask import render_template
from flask import request
import utils
import history

app = Flask(__name__)


@app.route('/')
def hello_world():
    return render_template("index.html")


@app.route('/time')
def get_time():
    return utils.get_time()


@app.route('/country', methods=["get", "post"])
def get_country_data():
    city = request.values.get("city")
    date = request.values.get("date")
    if (len(city) != 0) and (len(date) != 0):
        (content, labels) = utils.get_country_time(city, date)
    elif (len(city) != 0) and (len(date) == 0):
        (content, labels) = utils.get_country(city)

    elif (len(city) == 0) and (len(date) != 0):
        (content, labels) = utils.get_country_date(date)

    elif (len(city) == 0) and (len(date) == 0):
        (content, labels) = utils.get_country_time(city, date)

    return render_template("index.html", content=content, labels=labels)


@app.route('/city', methods=["get", "post"])
def get_city_data():
    city = request.values.get("city")
    date = request.values.get("date")
    if (len(city) != 0) and (len(date) != 0):
        print(city, date)
        (content, labels) = utils.get_city_time(city, date)

    elif (len(city) != 0) and (len(date) == 0):
        print(city + '123')
        (content, labels) = utils.get_city(city)

    elif (len(city) == 0) and (len(date) != 0):
        print(date)
        (content, labels) = utils.get_city_date(date)

    elif (len(city) == 0) and (len(date) == 0):
        (content, labels) = utils.get_city_time(city, date)
    return render_template("index.html", content=content, labels=labels)


@app.route('/china')
def get_china():
    res = utils.get_china()
    return jsonify({"data": res})


@app.route('/r1')
def get_r1():
    city, confirm = utils.get_r1()
    return jsonify({"city": city, "confirm": confirm})


if __name__ == '__main__':
    utils.create_database()
    history.city_time()
    app.run()
