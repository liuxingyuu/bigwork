import json
import pymssql
import requests
from bs4 import BeautifulSoup
import datetime
import utils


# 从网上爬取疫情数据
def catch():
    url = 'https://ncov.dxy.cn/ncovh5/view/pneumonia?from=timeline&isappinstalled=0'  # 请求地址
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36'}  # 创建头部信息
    response = requests.get(url, headers=headers)  # 发送网络请求
    # print(response.content.decode('utf-8'))#以字节流形式打印网页源码
    content = response.content.decode('utf-8')
    # print(content)
    soup = BeautifulSoup(content, 'html.parser')
    listA = soup.find_all(name='script', attrs={"id": "getAreaStat"})
    # 世界确诊getAreaStat
    listB = soup.find_all(name='script', attrs={"id": "getListByCountryTypeService2true"})
    # listA = soup.find_all(name='div',attrs={"class":"c-touchable-feedback c-touchable-feedback-no-default"})
    account = str(listA)
    world_messages = str(listB)[95:-21]
    messages = account[52:-21]
    messages_json = json.loads(messages)
    # print(world_messages)
    world_messages_json = json.loads(world_messages)
    valuesList = []
    cityList = []
    worldList = []
    now_time = datetime.datetime.now().strftime('%Y-%m-%d')

    for k in range(len(world_messages_json)):
        worldvalue = (
            now_time,
            world_messages_json[k].get('countryType'),
            world_messages_json[k].get('continents'),
            world_messages_json[k].get('provinceId'),
            world_messages_json[k].get('provinceName'),
            world_messages_json[k].get('provinceShortName'),
            world_messages_json[k].get('cityName'),
            world_messages_json[k].get('currentConfirmedCount'),
            world_messages_json[k].get('confirmedCount'),
            world_messages_json[k].get('suspectedCount'),
            world_messages_json[k].get('curedCount'),
            world_messages_json[k].get('deadCount'),
            world_messages_json[k].get('locationId'),
            world_messages_json[k].get('countryShortCode'),
            world_messages_json[k].get('statisticsData'))
        worldList.append(worldvalue)

    for i in range(len(messages_json)):
        # value = messages_json[i]
        value = (
            now_time,
            messages_json[i].get('provinceName'),
            messages_json[i].get('provinceShortName'),
            messages_json[i].get('currentConfirmedCount'),
            messages_json[i].get('confirmedCount'),
            messages_json[i].get('suspectedCount'),
            messages_json[i].get('curedCount'),
            messages_json[i].get('deadCount'),
            messages_json[i].get('comment'),
            messages_json[i].get('locationId'),
            messages_json[i].get('statisticsData'))
        valuesList.append(value)
        cityValue = messages_json[i].get('cities')
        # print(cityValue)
        for j in range(len(cityValue)):
            cityValueList = (
                cityValue[j].get('cityName'),
                cityValue[j].get('currentConfirmedCount'),
                cityValue[j].get('confirmedCount'),
                cityValue[j].get('suspectedCount'),
                cityValue[j].get('curedCount'),
                cityValue[j].get('deadCount'),
                cityValue[j].get('locationId'),
                messages_json[i].get('provinceShortName'))
            cityList.append(cityValueList)
        # cityList.append(cityValue)


    db,cursor=utils.get_conn()


    # 转换格式
    province_tuple = tuple(valuesList)
    city_tuple = tuple(cityList)
    world_Tuple = tuple(worldList)


    # 导入外国数据
    operation_1 = """
    IF OBJECT_ID('current_World', 'U') IS NOT NULL
        DROP TABLE current_World
    CREATE TABLE current_World(now_time VARCHAR(15),
    countryType INT,
    continents VARCHAR(15),
    provinceId INT,
    provinceName VARCHAR(20),
    provinceShortName VARCHAR(15),
    cityName VARCHAR(15),
    currentConfirmedCount INT,
    confirmedCount INT,
    suspectedCount INT,
    curedCount INT,
    deadCount INT,
    locationId INT,
    countryShortCode VARCHAR(20)
    )"""



    cursor.execute(operation_1)
    sql_world = "INSERT INTO current_World values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"  # 把数据插入到世界的数据库
    try:
        cursor.executemany(sql_world, world_Tuple)
        db.commit()
    except:
        print('导入国家数据失败，进入回调1')
        db.rollback()

    # 导入省的数据
    operation_2 = """
    IF OBJECT_ID('current_Province', 'U') IS NOT NULL
        DROP TABLE current_Province
    CREATE TABLE current_Province(
    now_time VARCHAR(100),
    provinceName VARCHAR(20),
    provinceShortName VARCHAR(20),
    currentConfirmedCount INT,
    confirmedCount INT,
    suspectedCount INT,
    curedCount INT,
    deadCount INT,
    comment VARCHAR(200),
    locationId INT,
    statisticsData VARCHAR(1200)
    )"""

    cursor.execute(operation_2)
    sql_province = "INSERT INTO current_Province values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) "  # 把数据插入到省的数据库
    try:
        cursor.executemany(sql_province, province_tuple)
        db.commit()
    except:
        print('导入省份数据失败，进入回调2')
        db.rollback()

    # 导入城市的数据
    operation_3 = """
    IF OBJECT_ID('current_City', 'U') IS NOT NULL
        DROP TABLE current_City
    CREATE TABLE current_City(
    cityName VARCHAR(25),
    currentConfirmedCount INT,
    confirmedCount  INT,
    suspectedCount  INT,
    curedCount  INT,
    deadCount  INT,
    locationId INT,
    provinceShortName VARCHAR(25)
    )"""

    cursor.execute(operation_3)
    sql_city = "INSERT INTO current_City values (%s,%s,%s,%s,%s,%s,%s,%s)"  # 把数据插入到城市的数据库
    try:
        cursor.executemany(sql_city, city_tuple)
        db.commit()
    except:
        print('导入城市数据失败，进入回调3')
        db.rollback()

    # 关闭数据库
    utils.close_conn(db,cursor)


if __name__ == '__main__':
    catch()
