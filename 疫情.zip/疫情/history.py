import json
import time
import utils
import pymssql

def create_database():
    connect=pymssql.connect(
        server='127.0.0.1',
        user='sa',
        password='123456',
        database="master",
        charset='utf8')
    cursor=connect.cursor()
    connect.autocommit(True)
    sql_create="""
    If db_id('Epidemic_Data') IS NOT NULL
        DROP Database Epidemic_Data
    Create database Epidemic_Data
    """
    cursor.execute(sql_create)
    connect.autocommit(False)
    cursor.close()
    connect.close()

def city_time():
    city_time_list = []
    time_values_list = []
    with open("DXYArea-TimeSeries.json", 'r', encoding='utf-8') as f:
        messages_json = json.loads(f.read())

    for i in range(len(messages_json)):
        city_time_value = messages_json[i].get('cities')
        time_stamp = messages_json[i].get('updateTime') / 1000
        time_array = time.localtime(time_stamp)
        other_style_time1 = time.strftime("%Y-%m-%d", time_array)
        other_style_time2 = time.strftime("%H", time_array)
        time_value = (
            messages_json[i].get('provinceName'),
            other_style_time1,
            other_style_time2,
            messages_json[i].get('currentConfirmedCount'),
            messages_json[i].get('confirmedCount'),
            messages_json[i].get('suspectedCount'),
            messages_json[i].get('curedCount'),
            messages_json[i].get('deadCount'),
            messages_json[i].get('comment')
        )
        time_values_list.append(time_value)
        if city_time_value is not None:
            for j in range(len(city_time_value)):
                city_time_value_list = (
                    messages_json[i].get('provinceShortName'),
                    city_time_value[j].get('cityName'),
                    other_style_time1,
                    other_style_time2,
                    city_time_value[j].get('currentConfirmedCount'),
                    city_time_value[j].get('confirmedCount'),
                    city_time_value[j].get('suspectedCount'),
                    city_time_value[j].get('curedCount'),
                    city_time_value[j].get('deadCount')
                )
                city_time_list.append(city_time_value_list)

    db, cursor = utils.get_conn()

    city_time_values_tuple = tuple(city_time_list)
    time_values_tuple = tuple(time_values_list)

    # 导入外部数据

    operation_1 = """
    IF OBJECT_ID('city_Time', 'U') IS NOT NULL
        DROP TABLE city_Time
    CREATE TABLE city_Time(
    provinceName  VARCHAR(50),
    cityName  VARCHAR(50),
    updateTime  VARCHAR(30),
    hour  VARCHAR(5),
    currentConfirmedCount  INT,
    confirmedCount  INT,
    suspectedCount  INT,
    curedCount  INT,
    deadCount  INT,
    )"""

    cursor.execute(operation_1)
    sql_time = "INSERT INTO city_Time values (%s,%s,%s,%s,%s,%s,%s,%s,%s)"  # 把数据插入到世界的数据库
    cursor.executemany(sql_time, city_time_values_tuple)
    db.commit()

    operation_2 = """
        IF OBJECT_ID('Time', 'U') IS NOT NULL
            DROP TABLE Time
        CREATE TABLE Time(
        provinceName  VARCHAR(50),
        updateTime  VARCHAR(30),
        hour  VARCHAR(5),
        currentConfirmedCount  INT,
        confirmedCount  INT,
        suspectedCount  INT,
        curedCount  INT,
        deadCount  INT,
        comment  VARCHAR(500)
        )"""

    cursor.execute(operation_2)
    sql_time = "INSERT INTO Time values (%s,%s,%s,%s,%s,%s,%s,%s,%s)"  # 把数据插入到世界的数据库

    cursor.executemany(sql_time, time_values_tuple)
    db.commit()

    # 关闭数据库
    utils.close_conn(db, cursor)


if __name__ == '__main__':
    create_database()
    city_time()
