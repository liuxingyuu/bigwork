

function gettime() {
    $.ajax({
        url: "/time",
        timeout: "10000",
        success: function (data) {
            $("#t2").html(data)
        },
        error: function (xhr, type, errorThrown) {
        }
    });
}


$('document').ready(function () {
    $("form").submit(function () {
        <!--alert($("city").val());-->
    });
});

function get_china_data() {
	$.ajax({
		url: '/china',
		timeout: 10000,
		success: function(data) {
			ec_center_option.series[0].data = data.data
			ec_center.setOption(ec_center_option)
		},
        error:function (xhr,type,errorThrown) {
        }
	})
}

//setInterval(get_china_data, 1000)

/*
function get_r1_data() {
	$.ajax({
		url: '/r1',
		timeout: 10000,
		success: function(data) {
			ec_right_option.dataset[0].source = data.data
			ec_right.setOption(ec_right_option)
		},
        error:function (xhr,type,errorThrown) {
        }
	})
}

setInterval(get_r1_data, 1000)*/

function get_r1_data() {
	$.ajax({
		url: '/r1',
		timeout: 10000,
		success: function(data) {
			ec_histogram_option.xAxis.data = data.city
			ec_histogram_option.series[0].data = data.confirm
			ec_histogram.setOption(ec_histogram_option)
		}
	})
}
setInterval(gettime, 1000)
get_china_data()
get_r1_data()