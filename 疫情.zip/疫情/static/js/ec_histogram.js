var ec_histogram = echarts.init(document.getElementById('r1'));


var ec_histogram_option = {
    xAxis: {
        type: 'category',
        data: []
    },
    yAxis: {
        type: 'value'
    },
    series: [{
        data: [],
        type: 'bar',
        showBackground: true,
        backgroundStyle: {
            color: 'rgba(220, 220, 220, 0.8)'
        }
    }]
};

ec_histogram.setOption(ec_histogram_option)