var ec_right = echarts.init(document.getElementById('r1'));
var ec_right_option = {
    legend: {},
    tooltip: {},
    dataset: {
        dimensions: ['name','value'],
        source: [{'name': '香港', 'value': 53},
            {'name': '内蒙古', 'value': 21},
            {'name': '四川', 'value': 17},
            {'name': '台湾', 'value': 7},
            {'name': '上海', 'value': 7},
            {'name': '广东', 'value': 6},
            {'name': '山东', 'value': 5}]
    },
    xAxis: {type: 'category'},
    yAxis: {},
    // Declare several bar series, each will be mapped
    // to a column of dataset.source by default.
    series: [
        {type: 'bar'}
    ]
};

ec_right.setOption(ec_right_option)