import time
import pymssql
import current


def get_time():
    time_str = time.strftime("%Y{}%m{}%d{} %X")
    return time_str.format("年", "月", "日")


def get_conn():
    conn = pymssql.connect(server='127.0.0.1',
                           user='sa',
                           password='123456',
                           database="Epidemic_Data",
                           charset='utf8')
    cursor = conn.cursor()
    return conn, cursor


def close_conn(conn, cursor):
    cursor.close()
    conn.close()


def query(sql, *args):
    conn, cursor = get_conn()
    cursor.execute(sql, args)
    res = cursor.fetchall()
    cols = cursor.description
    close_conn(conn, cursor)
    return res, cols


def query2(sql, *args):
    conn, cursor = get_conn()
    cursor.execute(sql, args)
    res = cursor.fetchall()
    close_conn(conn, cursor)
    return res


def get_country(city):
    sql = """
    Select provinceName,updateTime,hour,currentConfirmedCount, confirmedCount,suspectedCount,curedCount,deadCount
    From TIME
    Where provinceName=(%s)
"""
    content, cols = query(sql, city)
    labels = [l[0] for l in cols]
    labels = tuple(labels)
    content = tuple(content)
    return content, labels


def get_country_date(date):
    sql = """
    Select provinceName,updateTime,hour,currentConfirmedCount, confirmedCount,suspectedCount,curedCount,deadCount 
    From TIME
    Where updateTime =(%s)
"""
    content, cols = query(sql, date)
    labels = [l[0] for l in cols]
    labels = tuple(labels)
    content = tuple(content)
    return content, labels


def get_country_time(city, date):
    sql = """
    Select provinceName,updateTime,hour,currentConfirmedCount, confirmedCount,suspectedCount,curedCount,deadCount
    From TIME
    Where provinceName=(%s) and updateTime =(%s) 
"""
    content, cols = query(sql, city, date)
    labels = [l[0] for l in cols]
    labels = tuple(labels)
    content = tuple(content)
    return content, labels


def get_city(city):
    sql = """
    Select provinceName,cityName,updateTime,hour,currentConfirmedCount, confirmedCount,suspectedCount,curedCount,deadCount
    From city_Time
    Where cityName=(%s)
"""
    content, cols = query(sql, city)
    labels = [l[0] for l in cols]
    labels = tuple(labels)
    content = tuple(content)
    return content, labels


def get_city_date(date):
    sql = """
    Select provinceName,cityName,updateTime,hour,currentConfirmedCount, confirmedCount,suspectedCount,curedCount,deadCount
    From city_Time
    Where updateTime =(%s) 
"""
    content, cols = query(sql, date)
    labels = [l[0] for l in cols]
    labels = tuple(labels)
    content = tuple(content)
    return content, labels


def get_city_time(city, date):
    sql = """
    Select provinceName,cityName,updateTime,hour,currentConfirmedCount, confirmedCount,suspectedCount,curedCount,deadCount
    From city_Time
    Where cityName=(%s) and updateTime =(%s) 
"""
    content, cols = query(sql, city, date)
    labels = [l[0] for l in cols]
    labels = tuple(labels)
    content = tuple(content)
    return content, labels


def find_china():
    sql = """
    Select provinceShortName,currentConfirmedCount
    From current_Province
    """
    res, cols = query(sql)
    return res


def get_china():
    china_list = []

    current.catch()
    res = find_china()
    for ress in res:
        temp = {'name': ress[0], 'value': ress[1]}
        china_list.append(temp)

    return china_list


def find_r1():
    sql = """
    Select top 7 provinceShortName,currentConfirmedCount
    From current_Province
    order by currentConfirmedCount desc 
    """
    res, cols = query(sql)
    return res


def get_r1():
    current.catch()
    res = find_r1()
    city = []
    confirm = []
    for i, j in res:
        city.append(i)
        confirm.append(j)

    return city, confirm


if __name__ == "__main__":
    create_database()
